var index = 0;

function showSlide(n) {
    var slides = document.getElementsByClassName("carousel-item");
    
    for (var i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    
    slides[n].style.display = "block";
}

function nextSlide() {
    index++;
    
    if (index >= document.getElementsByClassName("carousel-item").length) {
        index = 0;
    }
    
    showSlide(index);
}

function previousSlide() {
    index--;
    
    if (index < 0) {
        index = document.getElementsByClassName("carousel-item").length - 1;
    }
    
    showSlide(index);
}

document.getElementsByClassName("next")[0].addEventListener("click", nextSlide);
document.getElementsByClassName("previous")[0].addEventListener("click", previousSlide);

showSlide(index);
